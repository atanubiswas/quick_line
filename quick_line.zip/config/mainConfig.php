<?php

return[
    "GLOBAL_ACTIVE"             => 1,
    "GLOBAL_INACTIVE"           => 0,
    "GLOBAL_SUCCESS_STATUS"     => 'Success',
    "GLOBAL_ERROR_STATUS"       => 'Error',
    "USER_IMAGE_DEFAULT_URL"    => 'https://ui-avatars.com/api/',
];